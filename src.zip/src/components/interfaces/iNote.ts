interface iNote {
  id: string;
  title: string;
  date: string;
  tags: string[];
}
export default iNote;